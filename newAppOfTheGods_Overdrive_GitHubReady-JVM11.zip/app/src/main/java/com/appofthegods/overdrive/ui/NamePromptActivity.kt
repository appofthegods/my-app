package com.appofthegods.overdrive.ui
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.appofthegods.overdrive.core.PrefKeys
import com.appofthegods.overdrive.core.SecurePrefs
import com.appofthegods.overdrive.databinding.ActivityNamePromptBinding
class NamePromptActivity: AppCompatActivity() {
    private lateinit var b: ActivityNamePromptBinding
    private lateinit var prefs: SecurePrefs
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = SecurePrefs(this)
        b = ActivityNamePromptBinding.inflate(layoutInflater); setContentView(b.root)
        b.btnContinue.setOnClickListener {
            val name = b.editName.text.toString().trim()
            if (name.isNotEmpty()) {
                prefs.putString(PrefKeys.USER_NAME,name)
                val isDev = name == "Developer Eddie Ray"
                prefs.putBoolean(PrefKeys.DEV_MODE,isDev)
                if (isDev && !prefs.getBoolean(PrefKeys.OVR_RULES_SET,false)) startActivity(Intent(this, DeveloperOptionsActivity::class.java))
                else startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }
}
