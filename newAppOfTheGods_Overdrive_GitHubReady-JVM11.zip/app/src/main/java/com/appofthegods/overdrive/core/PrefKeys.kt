package com.appofthegods.overdrive.core

object PrefKeys { const val PASS_OK="pass_ok"; const val USER_NAME="user_name"; const val DEV_MODE="dev_mode"; const val OVR_RULES_SET="overdrive_rules_set"; const val OVR_RULES="overdrive_rules" }
