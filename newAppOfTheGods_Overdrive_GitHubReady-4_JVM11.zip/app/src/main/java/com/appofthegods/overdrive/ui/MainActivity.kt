package com.appofthegods.overdrive.ui
import android.content.Context
import android.os.Bundle
import android.os.PowerManager
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.appofthegods.overdrive.core.PrefKeys
import com.appofthegods.overdrive.core.SecurePrefs
import com.appofthegods.overdrive.databinding.ActivityMainBinding
class MainActivity: AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SecurePrefs
    private var wakeLock: PowerManager.WakeLock? = null
    private var overdrive = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = SecurePrefs(this)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        val rulesSet = prefs.getBoolean(PrefKeys.OVR_RULES_SET,false)
        b.switchOverdrive.isEnabled = rulesSet
        b.status.text = if (rulesSet) getString(com.appofthegods.overdrive.R.string.overdrive_off)
                        else getString(com.appofthegods.overdrive.R.string.overdrive_needs_rules)
        b.switchOverdrive.setOnCheckedChangeListener { _, checked -> if (checked) enableOverdrive() else disableOverdrive() }
        b.btnOpenDev.setOnClickListener { startActivity(android.content.Intent(this, DeveloperOptionsActivity::class.java)) }
    }
    private fun enableOverdrive() {
        if (!prefs.getBoolean(PrefKeys.OVR_RULES_SET,false)) { b.switchOverdrive.isChecked=false; return }
        if (overdrive) return; overdrive = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 1f }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AppOfTheGods:Overdrive")
        try { wakeLock?.acquire(10*60*1000L) } catch (_:Exception) {}
        b.status.text = getString(com.appofthegods.overdrive.R.string.overdrive_on)
    }
    private fun disableOverdrive() {
        if (!overdrive) return; overdrive = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_:Exception) {}
        wakeLock = null
        b.status.text = getString(com.appofthegods.overdrive.R.string.overdrive_off)
    }
    override fun onDestroy() { disableOverdrive(); super.onDestroy() }
}
