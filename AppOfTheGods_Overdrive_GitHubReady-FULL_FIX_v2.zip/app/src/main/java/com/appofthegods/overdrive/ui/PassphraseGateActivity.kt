package com.appofthegods.overdrive.ui
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.appofthegods.overdrive.core.PrefKeys
import com.appofthegods.overdrive.core.SecurePrefs
import com.appofthegods.overdrive.databinding.ActivityPassphraseBinding
class PassphraseGateActivity: AppCompatActivity() {
    private lateinit var b: ActivityPassphraseBinding
    private lateinit var prefs: SecurePrefs
    private val required = "Ashley Cannon is the hottest wife a man can have!"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = SecurePrefs(this)
        if (prefs.getBoolean(PrefKeys.PASS_OK,false)) { startActivity(Intent(this, NamePromptActivity::class.java)); finish(); return }
        b = ActivityPassphraseBinding.inflate(layoutInflater); setContentView(b.root)
        b.btnSubmit.setOnClickListener {
            val entered = b.editPass.text.toString().trim()
            if (entered == required) { prefs.putBoolean(PrefKeys.PASS_OK,true); startActivity(Intent(this, NamePromptActivity::class.java)); finish() }
            else { finishAffinity() }
        }
    }
}
