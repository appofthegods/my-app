package com.appofthegods.overdrive.ui
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.appofthegods.overdrive.core.PrefKeys
import com.appofthegods.overdrive.core.SecurePrefs
import com.appofthegods.overdrive.databinding.ActivityDeveloperOptionsBinding
class DeveloperOptionsActivity: AppCompatActivity() {
    private lateinit var b: ActivityDeveloperOptionsBinding
    private lateinit var prefs: SecurePrefs
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = SecurePrefs(this)
        b = ActivityDeveloperOptionsBinding.inflate(layoutInflater); setContentView(b.root)
        b.editRules.setText(prefs.getString(PrefKeys.OVR_RULES,""))
        b.btnSave.setOnClickListener {
            val rules = b.editRules.text.toString().trim()
            if (rules.isEmpty()) { Toast.makeText(this,"Enter Overdrive laws/rules first.",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            prefs.putString(PrefKeys.OVR_RULES,rules)
            prefs.putBoolean(PrefKeys.OVR_RULES_SET,true)
            Toast.makeText(this,"Rules saved. Overdrive toggle enabled.",Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
