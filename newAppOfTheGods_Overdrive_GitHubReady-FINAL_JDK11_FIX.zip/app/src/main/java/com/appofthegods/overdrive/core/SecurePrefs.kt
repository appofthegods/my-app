package com.appofthegods.overdrive.core
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
class SecurePrefs(context: Context) {
    private val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(
        context, "secure_prefs", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun putBoolean(k:String,v:Boolean)=prefs.edit().putBoolean(k,v).apply()
    fun getBoolean(k:String,d:Boolean=false)=prefs.getBoolean(k,d)
    fun putString(k:String,v:String)=prefs.edit().putString(k,v).apply()
    fun getString(k:String,d:String="")=prefs.getString(k,d)?:d
    fun clearAll()=prefs.edit().clear().apply()
}
